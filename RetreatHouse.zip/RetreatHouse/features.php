<?php
  $conn = mysqli_connect('localhost', 'root', '', 'retreat_house');
  session_start();

	$status = 'hidden';
	$signin_status = '';

  if(isset($_SESSION['is_logged_in'])){ 
		$status = '';
		$signin_status = 'hidden';
		
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>BEATERIO DE MINDANAO</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">

  <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
  <link rel="stylesheet" href="css/animate.css">

  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">

  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/ionicons.min.css">

  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">


  <link rel="stylesheet" href="css/flaticon.css">
  <link rel="stylesheet" href="css/icomoon.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2"
    id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="home.php">BEATERIO DE MINDANAO</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
        aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>
      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown" <?php echo $status; ?>>
            <a class="nav-link dropdown-toggle" href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true"
              aria-expanded="false">
              <?php echo $_SESSION['name']; ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdown04">
              <a class="dropdown-item" href="">Profile</a>
              <a class="dropdown-item" href="signout.php">Sign Out</a>
            </div>
          </li>
          <li class="nav-item"><a href="index.php" class="nav-link" <?php echo $signin_status; ?>>Sign In</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
          <li class="nav-item"><a href="about.php" class="nav-link">About Us</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- END nav -->

  <div class="hero-wrap hero-bread" style="background-image: url('images/bg_6.jpg');">
    <div class="container">
      <div class="row no-gutters slider-text align-items-center justify-content-center">
        <div class="col-md-9 ftco-animate text-center">
          <h1 class="mb-0 bread">Features</h1>
          <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Home</a></span><span>Features</span></p>
        </div>
      </div>
    </div>
  </div>

  <section class="ftco-section ftco-degree-bg">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 ftco-animate">
          <h1 class="mb-3">Features</h1>
          <p>The Beaterio has the following features:</p>
          <h2 class="mt-5">Symbolism</h2>
          <h3 id="design">1. Design</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="storeys">2. Storeys</h3>
          <p>
            The three levels stand for the past, present and future; they also serve as easy clues for: the Ignacian
            core values of faith, excellence, and service; for the groups that were admitted in the orginal beaterio,
            namely, the yndia-mestiza-espanola and beatashermanas-recogidas.
          </p>

          <h3 id="colors">3. Colors</h3>
          <p>
            The main school colors within the Province are blue (St. Marys), pink (UIC), and green (Notre Dames). The
            main theme is yellow to symbolize the sun which shines for everyone and as a reminder of Easter and the
            resurrection.
          </p>

          <h3 id="ironworks">4. Ironworks</h3>
          <p>
            The eight petals stand for the beatitudes. The hearts symbolize the value of charity that permeated and
            characterized Mother Ignacia's community.
          </p>

          <h3 id="fountain">5. Fountain</h3>
          <p>
            The fourteen water spouts through which water flows stand for the 14 communities that compose the Southern
            Mindanao Province.
          </p>

          <h3 id="leafless-tree">6. Leafless Tree</h3>
          <p>
            This work of art assumes different meanings according to those who stand before it, meditate and reflect on
            it.
          </p>

          <h3 id="lady">7. Our Lady of the Beaterio</h3>
          <p>
            A painting done by June Silva in 1975, this representation honors Our Lady and her role in the RVM
            spirituality. The child Jesus she carries in her arms is a fitting reminder of childlike faith in a loving
            God.
          </p>
          <hr class="mt-5">
          <h2 class="mt-5">Prayer and Devotional Service Areas</h2>
          <h3 id="saints-rectoras">8. Saints and Rectoras</h3>
          <p>
            Considered as models for living the Christian life, their contribution in the RVM spirituality through the
            years is recognized.
          </p>

          <h3 id="labyrinth">9. Labyrinth</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="oratory">10. Oratory</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="chapel">11. Chapel</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="atrium">12. Atrium/Courtyard</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="garden-kiosks">13. Garden Kiosks</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <h3 id="baptismal">14. Simulated Baptismal Pool</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>

          <hr class="mt-5">
          <h2 class="mt-5">Practical Facilities</h2>
          <h3 id="admin">15. Administrator's Office</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <h3 id="individual-conference">16. Individual Conference Rooms</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <h3 id="mini-library">17. Mini Library</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <h3 id="conference">18. Conference Room</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <h3 id="refectory">19. Refectory</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <h3 id="herb-garden">20. Herb Garden</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>
          <hr class="mt-5">
          <h2 class="mt-5">Motif</h2>
          <h3 id="indigenoues-theme">21. Indigenous Theme</h3>
          <p>
            The four-sided building honors the east and west influences that are woven in the Filipino culture in
            general and the RVM spirituality in particular.
          </p>


        </div> <!-- .col-md-8 -->

        <div class="col-lg-4 sidebar ftco-animate">
          <div class="sidebar-box ftco-animate">
            <div class="categories">
              <h3>Categories</h3>
              <li><a href="#">Design</a></li>
              <li><a href="#design">Storeys</a></li>
              <li><a href="#storeys">Colors</a></li>
              <li><a href="#colors">Ironworks</a></li>
              <li><a href="#ironworks">Fountain</a></li>
              <li><a href="#fountain">Leafless Tree</a></li>
              <li><a href="#leafless-tree">Our Lady of the Beaterio</a></li>
              <li><a href="#lady">Saints and Rectoras</a></li>
              <li><a href="#saints-rectoras">Labyrinth</a></li>
              <li><a href="#labyrinth">Oratory</a></li>
              <li><a href="#oratory">Chapel</a></li>
              <li><a href="#chapel">Atrium/Courtyard</a></li>
              <li><a href="#atrium">Garden Kiosks</a></li>
              <li><a href="#garden-kiosks">Simulated Baptismal Pool</a></li>
              <li><a href="#baptismal">Administrator's Office</a></li>
              <li><a href="#admin">Individual Conference Rooms</a></li>
              <li><a href="#individual-conference">Mini Library</a></li>
              <li><a href="#mini-library">Conference Room</a></li>
              <li><a href="#conference">Refectory</a></li>
              <li><a href="#refectory">Herb Garden</a></li>
              <li><a href="#herb-garden">Indigenous Theme</a></li>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section> <!-- .section -->

  <footer class="ftco-footer bg-light ftco-section">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md">
          <div class="ftco-footer-widget mb-4 ml-md-5">
            <h2 class="ftco-heading-2">Menu</h2>
            <ul class="list-unstyled">
              <li><a href="#" class="py-2 d-block">About</a></li>
              <li><a href="#" class="py-2 d-block">Contact Us</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Help</h2>
            <div class="d-flex">
              <ul class="list-unstyled mr-l-5 pr-l-3 mr-4">
                <li><a href="#" class="py-2 d-block">Terms &amp; Conditions</a></li>
                <li><a href="#" class="py-2 d-block">Privacy Policy</a></li>
              </ul>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">FAQs</a></li>
                <li><a href="#" class="py-2 d-block">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Have a Questions?</h2>
            <div class="block-23 mb-3">
              <ul>
                <li><span class="icon icon-map-marker"></span><span class="text">203 Fake St. Mountain View, San
                    Francisco, California, USA</span></li>
                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+(062) 296-98-12</span></a></li>
                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">rvmsmp@yahoo.com</span></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">

          <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>
              document.write(new Date().getFullYear());
            </script> All rights reserved | Crezza</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
          </p>
        </div>
      </div>
    </div>
  </footer>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#F96D00" /></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false">
  </script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

</body>

</html>